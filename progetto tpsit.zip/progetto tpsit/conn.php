<?php
// Configurazione per la connessione al database
$host = "localhost";  // Server di database di XAMPP
$dbname = "audiowear";  // Nome del database che abbiamo creato
$username = "root";  // Username di default di XAMPP
$password = "";  // Password di default di XAMPP (vuota)

try {
    // Creazione della connessione PDO
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    // Imposta la modalità di errore PDO su eccezione
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Imposta il set di caratteri a utf8
    $conn->exec("SET NAMES utf8");
    
    // echo "Connessione al database riuscita"; // Decommentare per test
} catch(PDOException $e) {
    echo "Errore di connessione: " . $e->getMessage();
    die();
}
?>